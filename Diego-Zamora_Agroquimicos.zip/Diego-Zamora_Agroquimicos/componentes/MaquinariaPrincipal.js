import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// Import de mis Componentes
import CardMaquinaria from './CardMaquinaria';



class MaquinariaPrincipal extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getMaquinarias();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getMaquinarias = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/maquinarias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }

    render()
    {
        return(
            <section className="recetasIndex pt-5 mt-5">
                <div className="container">
                    <div className="row">
                        <div className="titulosReceta mx-auto">
                            <h2>
                                MAQUINARIA
                            </h2>
                            <hr className="hrMedianoD"/>
                            <p className="mt-3">
                                Conoce la Maquinaria Profesional que necesitan tus huertos y cultivos. Trabaja de una manera mas rapida y productiva.
                            </p>
                        </div>
                    </div>
                    <div className="row">
                    {
                        this.state.data ? 
                            this.state.data.map( 
                                e =>
                                    <CardMaquinaria
                                        quienSoy = {e.idMaquinaria}
                                        key = {e.idMaquinaria}
                                        nombre = {e.nombre}
                                        imagen = {e.imagen}
                                        marca = {e.marca}
                                        descripcion = {e.descripcion}
                                    />
                                )
                        : <h1 className="mx-auto">NO DATA :(</h1>
                    }

                    </div> 
                    <div className="row"> 
                    <div className="col-md-3 mx-auto">
                            <div className="verMasProductos mt-0">
                                <Link to="/maquinaria"><p><u>VER MÁS MAQUINARIA Y EQUIPO</u></p></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        );
    }
}

export default MaquinariaPrincipal;