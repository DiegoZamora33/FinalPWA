import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import durazno from '../img/durazno.png';
import zamora2 from '../img/zamora2.png';

class FooterPrincipal extends Component
{
    render()
    {
        return(
            <footer className="footer-distributed">
        
                <div className="footer-left">
                    <img src={zamora2} alt="logo"/>
                    <img src={durazno} alt="logo1"/>

                    <p className="footer-links">
                        <Link className="ml-2 mr-2" to="/">Inicio</Link>
                        |
                        <Link className="ml-2 mr-2" to="/sobre-nosotros">Sobre Nosotros</Link>
                        |
                        <Link className="ml-2 mr-2" to="/productos">Productos</Link>
                        |
                        <Link className="ml-2 mr-2" to="/maquinaria">Maquinaria</Link>
                        |
                        <Link className="ml-2 mr-2" to="/noticias">Noticias</Link>
                        |
                        <Link className="ml-2 mr-2" to="/necesito-asesoria">Asesoria</Link>
                        |
                        <Link className="ml-2 mr-2" to="/login">Login</Link>
                    </p>

                    <p className="footer-company-name">© 2020 Granja El Tepetate</p>
                </div>

                <div className="footer-center">
                    <div>
                        <i className="fa fa-map-marker"></i>
                        <p><span>Huajumbaro de Gpe.
                            S/N,C.P. 58963</span>
                            Municipio de
                            Zinapecuaro Michoacán</p>
                    </div>

                    <div>
                        <a href="tel:443-533-3739"><i className="fa fa-phone"></i></a>
                        <p><a href="tel:443-533-3739">+1 443-533-3739</a></p>
                    </div>
                    <div>
                        <a href="mailto:diego.zamora33.dz@gmail.com"><i className="fa fa-envelope"></i></a>
                        <p><a href="mailto:diego.zamora33.dz@gmail.com">diego.zamora33.dz@gmail.com</a></p>
                    </div>
                </div>
                <div className="footer-right">
                <div className="footer-company-about">
                    <span>Sobre la Empresa</span>
                    Somos una empresa comprometida a competir en el mercado con un productos de CALIDAD, MEJOR PRECIO Y OFERTAS.
                    <div className="footer-icons">
                        <a href="https://www.facebook.com/diego.zamora.332345/" target="blank"><i className="fa fa-facebook"></i></a>
                        <a href="https://www.youtube.com/watch?v=a8ejaL5AXo0" target="blank"><i className="fa fa-youtube"></i></a>
                    </div>
                </div>
                </div>
            </footer>

        );
    }
}

export default FooterPrincipal;