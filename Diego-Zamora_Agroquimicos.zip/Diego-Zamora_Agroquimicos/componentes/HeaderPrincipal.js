import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import carrito from '../img/carrito.png';
import durazno from '../img/durazno.png';
import zamora2 from '../img/zamora2.png';

class HeaderPrincipal extends Component
{
    render()
    {
        return(
            <div className="encabezadoIndex">
                <div className="container">
                <div className="header">
                        
                        <div id="arribaHeader">
                            <div id="headerInside">
                                <div id="tablaHeader">
                                    <div id="logoIndexHeader">
                                        <img id="imgHeader" alt="milogo" src={durazno}/>
                                    </div>
                                    <div id="infoHeader">
                                        <p className="pContacto">
                                        <b>Llámanos:</b> 443-533-3739
                                        <br></br>
                                        <b>Correo:</b> diego.zamora33.dz@gmail.com
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div id="headerInsideA">
                                <img className="mt-3" alt="otrologo" align="center" src={zamora2} height="104px" width="235px"/>
                            </div>
                            <div id="headerInside">
                                <button type="button" className="btn-carrito" data-toggle="modal" data-target="#modalCart">
                                    <img align="center" src={carrito} height="45px" width="45px" className="carritoImg"/>
                                </button>
                            </div>
                        </div>

                        <div className="d-none d-lg-block">
                            <hr className="hrMediano mt-1"/>
                            <div className="row">
                                <nav className="navbar-expand-md navbar-dark mx-auto mt-3 mb-3">
                                            <div className="collapse navbar-collapse">
                                                <ul className="navbar-nav mr-auto">
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/sobre-nosotros">Sobre nosotros</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/maquinaria">Maquinaria</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/productos">Productos</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/noticias">Noticias</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/necesito-asesoria">Necesito Asesoria</Link>
                                                    </li>
                                                </ul>
                                                <form className="form-inline ml-4 my-2 my-lg-0">
                                                    <div className="input-group-sm">
                                                        <input className="form-control mr-sm-2 " type="search" placeholder="Search" aria-label="Search"/>
                                                        <button className="btn btn-info my-2 my-sm-0 btn-sm" type="button">Search</button>
                                                    </div>
                                                </form>
                                            </div>
                                    </nav>
                                </div>
                            <hr className="hrMediano"/>
                        </div>

                        <div className="d-lg-none">
                            <hr className="hrMediano mt-1"/>
                            <div className="row">
                                <nav className="navbar-expand-md navbar-dark mx-auto mt-3 mb-3">
                                            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                                <span className="navbar-toggler-icon"></span>
                                            </button>

                                            <div className="collapse navbar-collapse bg-white mt-4" id="navbarSupportedContent">
                                                <ul className="navbar-nav mr-auto">
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/sobre-nosotros">Sobre nosotros</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/maquinaria">Maquinaria</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/productos">Productos</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/noticias">Noticias</Link>
                                                    </li>
                                                    <li className="nav-item mx-2">
                                                        <Link className="nav-link noTextShadow" to="/necesito-asesoria">Necesito Asesoria</Link>
                                                    </li>
                                                </ul>
                                                <form className="form-inline ml-3 mr-3">
                                                    <div className="input-group-sm mb-3">
                                                        <input className="form-control mr-sm-2 " type="search" placeholder="Search" aria-label="Search"/>
                                                        <button className="btn btn-info my-2 my-sm-0 btn-sm" type="submit">Search</button>
                                                    </div>
                                                </form>
                                            </div>
                                    </nav>
                                </div>
                            <hr className="hrMediano"/>
                        </div>


                    </div>
                    
                    <section className="banner pt-50 pb-50">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-6 mx-auto">
                                        <h2 className="text-white d-none d-sm-block d-md-block">ASESORÍA COMPLETAMENTE GRATIS</h2>
                                        <h1 className="text-white d-xl-none d-md-none d-sm-none">ASESORÍA PROFESIONAL GRATIS</h1>
                                        <p>Puedes escribirnos acerca de alguna duda o problema que tengas.</p>
                                        <p>
                                            Contamos con expertos en cotrol de plagas, desarrollo de cultivos
                                            y una extensa variedad en fertilizantes que mejoran la calidad de tu cosecha. 
                                        </p>
                                        <div className="primary-button">
                                            <Link to="/necesito-asesoria" className="scroll-link" data-id="book-table">NECESITO ASESORÍA</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </section>
                    </div>
                </div>
        );
    }
}

export default HeaderPrincipal;