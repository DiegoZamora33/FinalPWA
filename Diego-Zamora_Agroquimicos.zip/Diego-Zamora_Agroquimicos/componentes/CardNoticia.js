import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class CardNoticia extends Component
{
    constructor(props){
        super(props);
    }
    
    render()
    {
        return(
            <section className="featured-food pt-5">
                <div className="container mb-5">
                    {
                        this.props.data ? 
                            this.props.data.map( 
                                 e =>
                                    <div key={e.idNoticia} className="card mx-auto w-75 mb-5">
                                        <div className="card btn btn-light p-0 text-left" >
                                            <h2 className="card-header text-white bg-dark mb-0 font-weight-bold">Noticia</h2>
                                            <div className="row">
                                                    <img className="col-md-4 col-sm-12 m-2" src={e.imagen} alt={e.titulo} ></img>
                                                

                                                <div className="col-md-7 col-sm-12 mt-4">
                                                    <div className="card-text mt-1 pl-2 pr-2 d-flex"><h2 className="font-weight-bold mr-2">{e.titulo}</h2></div>
                                                    <div className="card-text pl-2 pr-2 d-flex">
                                                        <h2>
                                                            {e.texto}
                                                        </h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            )

                        : <h1 className="mx-auto">NO DATA :(</h1>
                    }

                    <div className="row mt-0">
                        <div className="verMasProductos mt-0">
                            <Link to="/noticias"><p><u>VER MÁS NOTICIAS</u></p></Link>
                        </div>
                    </div>
                </div>
            </section>
            
        );
    }
}

export default CardNoticia;