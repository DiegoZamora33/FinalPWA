import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class CardMaquinaria extends Component
{
    constructor(props) 
    {
        super(props);
        this.getPerfilMaquinaria = this.getPerfilMaquinaria.bind(this);
    }
    
    getPerfilMaquinaria(e) 
    {
        localStorage.setItem('idMaquinaria', e.target.id)
        //window.location = '/perfil-maquinaria';
    }
    render()
    {
        return(

            <div className="col-md-6">
                <div className="tableRecetas">
                        <div className="recetaIndex">
                            <div className="recetaContenido">
                                <div className="recetaImg" style={{
                                    background: 'url('+this.props.imagen+')center center',
                                    WebkitBackgroundSize: 'cover',
                                    MozBackgroundSize: 'cover',
                                    OBackgroundSize: 'cover',
                                    backgroundSize: 'cover',
                                    
                                    }}>
                                </div>
                                <div className="recetaContainer">
                                    <div className="tituloReceta mt-4">
                                        <h1>{this.props.nombre}</h1>
                                    </div>
                                    <div className="descReceta">
                                        <p>
                                            <b>{this.props.clasificacion}</b>  <br/>
                                            <b>Marca:</b> {this.props.marca} <br/>
                                            <b>Descripción:</b> {this.props.descripcion} <br/>
                                        </p>
                                    </div>
                                    <Link to="/perfil-maquinaria" id={this.props.quienSoy} onClick={this.getPerfilMaquinaria} className="text-white verReceta" style={{
                                        fontSize: '15px',
                                    }}>VER MAS</Link>
                                </div>
                            </div>
                        </div>
                </div>
            </div>

        );
    }
}

export default CardMaquinaria;