import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import StockAsesorias from './StockAsesorias';

class CardAsesoriaAdmin extends Component
{
    constructor(props) 
    {
        super(props);
    
        this.deleteAsesoria = this.deleteAsesoria.bind(this);
        this.showDelAsesoria = this.showDelAsesoria.bind(this);
        this.hideDelAsesoria = this.hideDelAsesoria.bind(this);
    }

    showDelAsesoria(e) 
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div className="alert alert-info" id="mimodal">
                 <label>Desea eliminar este Registro??</label><br/>
                <button id={e.target.id} onClick={this.deleteAsesoria} className="btn btn-warning btn-sm ml-1" >SI</button>
                
                <button id={e.target.id} onClick={this.hideDelAsesoria} className="btn btn-info btn-sm ml-1" >NO</button>
            </div>,
        document.getElementById('miConfirm'+e.target.id));
         
    }

    hideDelAsesoria(e)
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div>

            </div>,
        document.getElementById('miConfirm'+e.target.id));
    }

    deleteAsesoria(e)
    {
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/delAsesoria';
        var formData = new FormData();
        formData.append("idAsesoria", e.target.id);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
             
           console.log(texto['respuesta'])
            ReactDOM.render(
                <StockAsesorias/>,
            document.getElementById('mostrador'));
            
         })
         .catch(function(err) {
            console.log(err);
         })
    }

    render()
    {
        return(
            <section className="featured-food pt-5">
                <div className="container mb-5">
                    {
                        this.props.data ? 
                            this.props.data.map( 
                                 e =>
                                    <div key={e.idAsesoria} className="card mx-auto w-75 mb-5">
                                        <div className="card btn btn-light p-0 text-left" >
                                            <h2 className="card-header text-white bg-dark mb-0 font-weight-bold">{e.nombre}</h2>
                                            <div className="row">
                                                <div className="col-md-12 col-sm-12 mt-4">
                                                    <div className="card-text pl-2 pr-2 d-flex">
                                                    <p>
                                                        <b>Telefono:</b> {e.telefono} <br/>
                                                        <b>Correo:</b> {e.correo} <br/>
                                                        <b>Duda:</b> {e.texto} <br/>
                                                    </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row mt-2">
                                            <div className="mx-auto" id={'miConfirm'+e.idAsesoria}>
                                            </div>
                                        </div>
                                        
                                        <div className="row mb-2">
                                            <div className="mx-auto">
                                                <button id={e.idAsesoria} onClick={this.showDelAsesoria} className="btn btn-danger btn-sm ml-1" >Eliminar</button>
                                            </div>
                                        </div>
                                    </div>
                            )

                        : <h1 className="mx-auto">NO DATA :(</h1>
                    }
                </div>
            </section>
            
        );
    }
}

export default CardAsesoriaAdmin;