import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';
import { Link } from 'react-router-dom';

// Import de mis Componentes
import LogoReact from './LogoReact';
import FadeIn from 'react-fade-in';

class Login extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            ip: "",
        };
    }

    onSubmit(e){
        e.preventDefault()
        fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/login', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email : $('#email').val(),
                password : $('#password').val(),
            })
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
             if(texto['respuesta'] == 'true')
             {
                localStorage.setItem('user', $('#email').val());
                localStorage.setItem('pass', $('#password').val());
                //window.location = "/home";
                document.getElementById('miLog').style = "display: none";
                document.getElementById('log').style = "display: block";
             }
             else
             {
                ReactDOM.render(
                    <div class="alert alert-danger">
                        Usuario o Contraseña incorrectos.
                    </div>,
                document.getElementById('miAlert'));
                $('#password').val('');
             }
         })
         .catch(function(err) {
            console.log(err);
         });
    }

    render()
    {
        return(
            <FadeIn>

                <div className="container text-center d-lg-block d-md-block d-sm-none">
                    <div className="row flex-column flex-md-row login shadow fondo p-3 mb-5 rounded">
                        <div className="col col-md-6 col-sm-12 mx-auto">
                            <br/><br/>
                            
                                <LogoReact/>

                            <br/><br/>
                            <h4>SISTEMA PARA CONTROL</h4>
                            <h4 className="font-weight-bold" >DE DATOS Y ESTADÍSTICAS</h4><br/>

                            <div id="miAlert">
                            </div>
                            
                            <div id="log" style={{display: 'none'}}>
                                    <div class="alert alert-danger">
                                        <h1>Bienvenido</h1><br/>.
                                        <Link className="btn btn-primary" to="/home">Entrar</Link>
                                    </div>
                            </div>

                                 <form id="miLog" className="mt-4"  onSubmit={this.onSubmit} >

                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Correo Electrónico</label>
                                            <input id="email" type="email" className="form-control" name="email" required />
                                        </div>


                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Contraseña</label>
                                            <input id="password" type="password" className="form-control" name="password" required /> 
                                        </div>


                                        <small id="emailHelp" className="form-text text-muted">Si no recuerdas la contraseña, comunicate con algún administrador.</small>
                                        <br/>
                                        <button type="submit" className="btn btn-primary mb-2">INICIAR SESIÓN</button>

                                </form>
                            
                            
                        </div>
                    </div>
                </div>
            </FadeIn> 
        );
    }
}

export default Login;