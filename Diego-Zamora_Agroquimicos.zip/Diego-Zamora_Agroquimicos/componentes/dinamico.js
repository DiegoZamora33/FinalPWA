import $ from 'jquery';

$(document).ready(function ()
{
    // Funcion para el menu
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $('#lateral').toggleClass('active');
    });
});