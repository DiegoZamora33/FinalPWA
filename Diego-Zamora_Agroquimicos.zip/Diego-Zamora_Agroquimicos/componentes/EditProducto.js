import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';

// Import de mis Componentes
import FadeIn from 'react-fade-in';
import StockProductos from './StockProductos';

class EditProducto extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            data : [],
            nombre: ' ',
            marca: ' ',
            clasificacion: ' ',
            precioUnitario: ' ',
            stock: ' ',
            ingredienteActivo: ' ',
            descripcion: ' ',
            formaAplicacion: ' ',
        };
        this.handleChange = this.handleChange.bind(this);
    }

    async componentDidMount()
    {
        await this.getProducto();
    }

    returnProductos = async () =>
    {
        ReactDOM.render(
            <StockProductos/>,
        document.getElementById('mostrador'));
    }

    getProducto = async () =>  
    {
        
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/getProducto', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idProducto : this.props.get,
            })
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            return texto;
         })
         .catch(function(err) {
            console.log(err);
         });

         this.setState({
             data: res['respuesta'][0]
         });

         let aux;

        aux = this.state.data.nombre
         this.setState({
            nombre: aux
        });
        aux = this.state.data.marca
         this.setState({
            marca: aux
        });
        aux = this.state.data.clasificacion
         this.setState({
            clasificacion: aux
        });
        aux = this.state.data.ingredienteActivo
         this.setState({
            ingredienteActivo: aux
        });
        aux = this.state.data.precioUnitario
         this.setState({
            precioUnitario: aux
        });
        aux = this.state.data.stock
         this.setState({
            stock: aux
        });
        aux = this.state.data.descripcion
         this.setState({
            descripcion: aux
        });
        aux = this.state.data.formaAplicacion
         this.setState({
            formaAplicacion: aux
        });



        console.log(res['respuesta']);
    }

    
    onSubmit(e){
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/editProducto';
        let fileN = document.getElementById('imagenProducto');
        var formData = new FormData();
        formData.append("idProducto", $('#idProducto').val());
        formData.append("nombre", $('#nombre').val());
        formData.append("marca", $('#marca').val());
        formData.append("clasificacion", $('#clasificacion').val());
        formData.append("ingredienteActivo", $('#ingredienteActivo').val());
        formData.append("precioUnitario", $('#precioUnitario').val());
        formData.append("stock", $('#stock').val());
        formData.append("descripcion", $('#descripcion').val());
        formData.append("formaAplicacion", $('#formaAplicacion').val());
        formData.append("imagenProducto", fileN.files[0]);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            ReactDOM.render(
                <div className="alert alert-info">
                    El producto se Actualizó con Exito
                </div>,
            document.getElementById('miAlert'));
            ReactDOM.render(
                <div className="alert alert-info">
                    El producto se Actualizó con Exito
                </div>,
            document.getElementById('miAlert2'));
            console.log(texto['respuesta']);
         })
         .catch(function(err) {
            console.log(err);
         });
    }

    handleChange(event) 
    {
        switch(event.target.id)
        {
            case 'nombre':
                this.setState({nombre: event.target.value});
            break;

            case 'marca':
                this.setState({marca: event.target.value});
            break;

            case 'ingredienteActivo':
                this.setState({ingredienteActivo: event.target.value});
            break;
            
            case 'clasificacion':
                this.setState({clasificacion: event.target.value});
            break;
            
            case 'precioUnitario':
                this.setState({precioUnitario: event.target.value});
            break;
            
            case 'stock':
                this.setState({stock: event.target.value});
            break;
            
            case 'descripcion':
                this.setState({descripcion: event.target.value});
            break;
            
            case 'formaAplicacion':
                this.setState({formaAplicacion: event.target.value});
            break;
        }
    }


    render()
    {
        return(
            <FadeIn>
                
                <div className="row">

                    <div className="text-left col-md-2">
                    <a onClick={this.returnProductos}  type="button" style={{cursor: 'pointer'}}  className="bg-primary border border-primary rounded p-1 superBoton text-left text-success">
                    <i className="align-middle fa fa-arrow-left text-white" style={{fontSize: '24px'}}></i>
                        <label className="mt-2 text-white d-md-inline" style={{cursor: 'pointer', fontSize: '15px'}}>Atras</label>
                    </a>
                    </div>

                </div>
                <form onSubmit={this.onSubmit} id="formNewProducto" className="form-horizontal border pt-4 pb-5 mt-5">
                    <input value={this.state.data.idProducto} type="hidden" id="idProducto" />
                            
                    <div className="row">
                        <img className="col-lg-4 col-sm-12 mx-auto" src={this.state.data.imagen} />  
                    </div>
                    <div className="row mt-4">
                        <div className="mx-auto border p-5 bg-light col-lg-7 col-sm-12">
                            
                            <div className="mb-3 mt-3" id="miAlert2">
                            </div>

                            <div className="form-group">
                                <label>Nombre</label>
                                <input onChange={this.handleChange}  value={this.state.nombre} type="text" className="form-control" id="nombre" name="nombre" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Marca</label>
                                <input onChange={this.handleChange}  value={this.state.marca}  type="text" className="form-control" id="marca" name="marca" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Clasificación</label>
                                <input onChange={this.handleChange}  value={this.state.clasificacion}  type="text" className="form-control" id="clasificacion" name="clasificacion" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Ingrediente Activo</label>
                                <input onChange={this.handleChange}  value={this.state.ingredienteActivo}  type="text" className="form-control" id="ingredienteActivo" name="ingredienteActivo" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$" required/>
                            </div>

                            <div className="form-group">
                                <label>Precio Unitario</label>
                                <input onChange={this.handleChange}   value={this.state.precioUnitario}  type="number" className="form-control" id="precioUnitario" name="precioUnitario" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$" required/>
                            </div>
                            <div className="form-group">
                                <label>Stock</label>
                                <input onChange={this.handleChange}  value={this.state.stock}  type="number" className="form-control" id="stock" name="stock" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$" required/>
                            </div>

                            <div className="form-group">
                                <label>Descripcion</label>
                                <textarea onChange={this.handleChange}  value={this.state.descripcion} type="text" className="form-control" id="descripcion" name="descripcion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>
                            <div className="form-group">
                                <label>Forma de Aplicación</label>
                                <textarea onChange={this.handleChange}  value={this.state.formaAplicacion} type="text" className="form-control" id="formaAplicacion" name="formaAplicacion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>

                            <div className="form-group">
                                <label>Foto</label>
                                <input type="file" className="form-control" id="imagenProducto" name="imagenProducto" accept="image/*"></input>
                                <small className="form-text text-muted">Sube una imagen del Producto</small>
                            </div>
                            
                            <div className="form-row">
                                <button type="submit" className="btn btn-warning mx-auto">Guardar</button>
                            </div>

                            <div className="mt-4" id="miAlert">
                            </div>
                        </div>
                    </div>
                </form>
            </FadeIn>

        );
    }
}

export default EditProducto;