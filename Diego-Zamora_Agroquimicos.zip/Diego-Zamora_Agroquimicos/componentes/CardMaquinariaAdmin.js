import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Route, Redirect } from 'react-router-dom';
import $ from 'jquery';

// Import de mis Componentes
import EditMaquinaria from './EditMaquinaria';
import StockMaquinaria from './StockMaquinaria';

class CardMaquinariaAdmin extends Component
{
    constructor(props) 
    {
        super(props);
        this.state = {
            idProducto : ' ',
        };
        this.getPerfilMaquinaria = this.getPerfilMaquinaria.bind(this);
        this.deleteMaquina = this.deleteMaquina.bind(this);
        this.showDelAsesoria = this.showDelAsesoria.bind(this);
        this.hideDelAsesoria = this.hideDelAsesoria.bind(this);
    }

    showDelAsesoria(e) 
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div className="alert alert-info" id="mimodal">
                 <label>Desea eliminar este Registro??</label><br/>
                <button id={e.target.id} onClick={this.deleteMaquina} className="btn btn-warning btn-sm ml-1" >SI</button>
                
                <button id={e.target.id} onClick={this.hideDelAsesoria} className="btn btn-info btn-sm ml-1" >NO</button>
            </div>,
        document.getElementById('miConfirm'+e.target.id));
         
    }

    hideDelAsesoria(e)
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div>

            </div>,
        document.getElementById('miConfirm'+e.target.id));
    }

    deleteMaquina(e)
    {
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/delMaquinaria';
        var formData = new FormData();
        formData.append("idMaquinaria", e.target.id);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
             
           console.log(texto['respuesta'])
            
         })
         .catch(function(err) {
            console.log(err);
         })
        ReactDOM.render(
            <StockMaquinaria/>,
        document.getElementById('mostrador'));
    }

    getPerfilMaquinaria(e) 
    {
        ReactDOM.render(
            <EditMaquinaria get={e.target.id}/>,
        document.getElementById('mostrador'));
    }

    render()
    {
        return(
            <div className="col-md-6">
                <div className="tableRecetas">
                        <div className="recetaIndex">
                            <div className="recetaContenido">
                                <div className="recetaImg" style={{
                                    background: 'url('+this.props.imagen+')center center',
                                    WebkitBackgroundSize: 'cover',
                                    MozBackgroundSize: 'cover',
                                    OBackgroundSize: 'cover',
                                    backgroundSize: 'cover',
                                    
                                    }}>
                                </div>
                                <div className="recetaContainer">
                                    <div className="tituloReceta mt-4">
                                        <h1>{this.props.nombre}</h1>
                                    </div>
                                    <div className="descReceta">
                                        <p>
                                            <b>{this.props.clasificacion}</b>  <br/>
                                            <b>Marca:</b> {this.props.marca} <br/>
                                            <b>Descripción:</b> {this.props.descripcion} <br/>
                                        </p>
                                        <div className="row">
                                            <div className="mx-auto" id={'miConfirm'+this.props.quienSoy}>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row mt-2">
                                        <div className="mx-auto">
                                            <button id={this.props.quienSoy} onClick={this.getPerfilMaquinaria} className="text-white btn btn-warning btn-sm" style={{
                                                fontSize: '15px',
                                            }}>Editar</button>
                                            <button onClick={this.showDelAsesoria} id={this.props.quienSoy} className="ml-2 text-white btn btn-danger btn-sm" style={{
                                                fontSize: '15px',
                                            }}>Eliminar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>

        );
    }
}

export default CardMaquinariaAdmin;