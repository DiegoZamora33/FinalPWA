import React, { Component } from 'react';

class Carrucel extends Component
{
    constructor(props){
        super(props);

    }
    
    render()
    {
        return(
            <div className="container mb-5 mt-5">
                {   
                    this.props.data ?    
                        <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel">
                            <ol className="carousel-indicators">
                                {
                                    this.props.data.map( 
                                         e =>

                                         <li data-target="#carouselExampleIndicators"  key={e.miID} data-slide-to={e.miID} className={e.miID == 1 ? 'active' : ' ' } ></li>
                                
                                    )
                                }
                            </ol>
                            <div className="carousel-inner">
                                {
                                    this.props.data.map( 
                                         x =>
                                        <div key={x.miID} className={x.miID == 1 ? 'carousel-item active' : 'carousel-item' }>
                                            <img className="d-block w-100" src={x.imagen}/>
                                        </div>
                                    )
                                }

                            </div>
                            <a className="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span className="sr-only">Previous</span>
                            </a>
                            <a className="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                <span className="sr-only">Next</span>
                            </a>
                        </div>

                    : <h1 className="mx-auto">NO DATA :(</h1>
                }
                
            </div>
            );
    }
}

export default Carrucel;