import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';


// Import de mis Componentes
import FadeIn from 'react-fade-in';
import StockNoticia from './StockNoticias';

class NuevaNoticia extends Component
{
    returnProductos = async () =>
    {
        ReactDOM.render(
            <StockNoticia/>,
        document.getElementById('mostrador'));
    }
    onSubmit(e){
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/newNoticia';
        let fileN = document.getElementById('imagenProducto');
        var formData = new FormData();
        formData.append("titulo", $('#titulo').val());
        formData.append("texto", $('#texto').val());
        formData.append("imagenProducto", fileN.files[0]);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            ReactDOM.render(
                <div class="alert alert-info">
                    La Noticia se Agregó con Exito
                </div>,
            document.getElementById('miAlert'));
            ReactDOM.render(
                <div class="alert alert-info">
                    La Noticia se Agregó con Exito
                </div>,
            document.getElementById('miAlert2'));
            $('#formNewProducto').trigger("reset");
            console.log(texto['respuesta']);
         })
         .catch(function(err) {
            console.log(err);
         });
    }
    render()
    {
        return(
            <FadeIn>
                
                <div className="row">

                    <div className="text-left col-md-2">
                    <a onClick={this.returnProductos}  type="button" style={{cursor: 'pointer'}}  className="bg-primary border border-primary rounded p-1 superBoton text-left text-success">
                    <i className="align-middle fa fa-arrow-left text-white" style={{fontSize: '24px'}}></i>
                        <label className="mt-2 text-white d-md-inline" style={{cursor: 'pointer', fontSize: '15px'}}>Atras</label>
                    </a>
                    </div>

                </div>
                <form  onSubmit={this.onSubmit} id="formNewProducto" className="form-horizontal border pt-4 pb-5 mt-5">
                    <div className="row">
                            <h2 className="mx-auto col-12"  style={{
                                textAlign: 'center',
                                fontFamily: 'Roboto',
                                color: '#771414',
                            }}>
                            Agregar una Nueva Noticia
                            </h2>
                            <small id="emailHelp" className="form-text text-center text-muted col-12"> 
                            Llena los siguientes campos para agregar una Nueva Noticia al catalogo
                            </small>   
                        </div>
                    <div className="row mt-4">
                        <div className="mx-auto border p-5 bg-light col-lg-7 col-sm-12">
                            
                            <div className="mb-3 mt-3" id="miAlert2">
                            </div>

                            <div className="form-group">
                                <label>Titulo</label>
                                <input type="text" className="form-control" id="titulo" name="titulo" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Texto</label>
                                <textarea type="text" className="form-control" id="texto" name="texto" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>
                            <div className="form-group">
                                <label>Foto</label>
                                <input type="file" className="form-control" id="imagenProducto" name="imagenProducto" accept="image/*"></input>
                                <small className="form-text text-muted">Sube una imagen del Producto</small>
                            </div>
                            
                            <div className="form-row">
                                <button type="submit" className="btn btn-warning mx-auto">Guardar</button>
                            </div>

                            <div className="mt-4" id="miAlert">
                            </div>
                        </div>
                    </div>
                </form>
            </FadeIn>

        );
    }
}

export default NuevaNoticia;