import React, { Component } from 'react';
import ReactDOM from 'react-dom';

// Import de mis Componentes
import CardMaquinariaAdmin from './CardMaquinariaAdmin';
import NuevaMaquinaria from './NuevaMaquinaria';
import FadeIn from 'react-fade-in';

class StockMaquinaria extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getMaquinarias();
    }

    getMaquinarias = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/maquinarias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }

    newMaquinaria = async () =>
    {
        ReactDOM.render(
            <NuevaMaquinaria/>,
        document.getElementById('mostrador'));
    }



    render()
    {
        return(

                <FadeIn>
                    <div className="row mb-1">
                            <div className="mx-auto">
                                <button type="button" className="btn btn-primary" onClick={this.newMaquinaria} data-toggle="modal" data-target="#modalNewProducto">
                                    
                                    <i className="fa fa-plus-circle"></i>
                                    <span className="ml-2">Nueva Maquinaria</span>
                                </button>
                            </div>
                    </div>
                   <div className="row mt-5">
                   {
                        this.state.data ? 
                            this.state.data.map( 
                                e =>
                                    <CardMaquinariaAdmin
                                        quienSoy = {e.idMaquinaria}
                                        key = {e.idMaquinaria}
                                        nombre = {e.nombre}
                                        imagen = {e.imagen}
                                        marca = {e.marca}
                                        descripcion = {e.descripcion}
                                    />
                            )
                        : <h1 className="mx-auto">NO DATA :(</h1>
                    }
                    </div>
                </FadeIn>

        );
    }
}

export default StockMaquinaria;