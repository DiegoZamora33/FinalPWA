import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import EditNoticia from './EditNoticia';
import StockNoticias from './StockNoticias';

class CardNoticiaAdmin extends Component
{
    constructor(props) 
    {
        super(props);
        this.state = {
            idProducto : ' ',
        };
        this.getPerfilNoticia = this.getPerfilNoticia.bind(this);
        this.deleteNoticia = this.deleteNoticia.bind(this);
        this.showDelNoticia = this.showDelNoticia.bind(this);
        this.hideDelNoticia = this.hideDelNoticia.bind(this);
    }

    
    showDelNoticia(e) 
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div className="alert alert-info" id="mimodal">
                 <label>Desea eliminar este Registro??</label><br/>
                <button id={e.target.id} onClick={this.deleteNoticia} className="btn btn-warning btn-sm ml-1" >SI</button>
                
                <button id={e.target.id} onClick={this.hideDelNoticia} className="btn btn-info btn-sm ml-1" >NO</button>
            </div>,
        document.getElementById('miConfirm'+e.target.id));
         
    }

    hideDelNoticia(e)
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div>

            </div>,
        document.getElementById('miConfirm'+e.target.id));
    }

    deleteNoticia(e)
    {
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/delNoticia';
        var formData = new FormData();
        formData.append("idNoticia", e.target.id);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
             
           console.log(texto['respuesta'])
            ReactDOM.render(
                <StockNoticias/>,
            document.getElementById('mostrador'));
            
         })
         .catch(function(err) {
            console.log(err);
         })
    }


    getPerfilNoticia(e) 
    {
        ReactDOM.render(
            <EditNoticia get={e.target.id} />,
        document.getElementById('mostrador'));
    }
    
    render()
    {
        return(
            <section className="featured-food pt-5">
                <div className="container mb-5">
                    {
                        this.props.data ? 
                            this.props.data.map( 
                                 e =>
                                    <div key={e.idNoticia} className="card mx-auto w-75 mb-5">
                                        <div className="card btn btn-light p-0 text-left" >
                                            <h2 className="card-header text-white bg-dark mb-0 font-weight-bold">Noticia</h2>
                                            <div className="row">
                                                    <img className="col-md-4 col-sm-12 m-2" src={e.imagen} alt={e.titulo} ></img>
                                                

                                                <div className="col-md-7 col-sm-12 mt-4">
                                                    <div className="card-text mt-1 pl-2 pr-2 d-flex"><h2 className="font-weight-bold mr-2">{e.titulo}</h2></div>
                                                    <div className="card-text pl-2 pr-2 d-flex">
                                                        <h2>
                                                            {e.texto}
                                                        </h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row mt-2">
                                            <div className="mx-auto" id={'miConfirm'+e.idNoticia}>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="mx-auto">
                                                <button id={e.idNoticia} onClick={this.getPerfilNoticia} className="btn btn-warning btn-sm mr-1" >Editar</button>
                                                <button id={e.idNoticia} onClick={this.showDelNoticia} className="btn btn-danger btn-sm ml-1" >Eliminar</button>
                                            </div>
                                        </div>
                                    </div>
                            )

                        : <h1 className="mx-auto">NO DATA :(</h1>
                    }
                </div>
            </section>
            
        );
    }
}

export default CardNoticiaAdmin;