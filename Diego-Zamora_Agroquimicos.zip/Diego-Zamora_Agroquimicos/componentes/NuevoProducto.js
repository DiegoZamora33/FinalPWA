import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FadeIn from 'react-fade-in';
import $ from 'jquery';

//Import de mi Componentes
import StockProductos from '../componentes/StockProductos';

class NuevoProducto extends Component
{
    returnProductos = async () =>
    {
        ReactDOM.render(
            <StockProductos/>,
        document.getElementById('mostrador'));
    }

    onSubmit(e){
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/newProducto';
        let fileN = document.getElementById('imagenProducto');
        var formData = new FormData();
        formData.append("nombre", $('#nombre').val());
        formData.append("marca", $('#marca').val());
        formData.append("clasificacion", $('#clasificacion').val());
        formData.append("ingredienteActivo", $('#ingredienteActivo').val());
        formData.append("precioUnitario", $('#precioUnitario').val());
        formData.append("stock", $('#stock').val());
        formData.append("descripcion", $('#descripcion').val());
        formData.append("formaAplicacion", $('#formaAplicacion').val());
        formData.append("imagenProducto", fileN.files[0]);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            ReactDOM.render(
                <div class="alert alert-info">
                    El producto se Agregó con Exito
                </div>,
            document.getElementById('miAlert'));
            ReactDOM.render(
                <div class="alert alert-info">
                    El producto se Agregó con Exito
                </div>,
            document.getElementById('miAlert2'));
            $('#formNewProducto').trigger("reset");
            console.log(texto['respuesta']);
         })
         .catch(function(err) {
            console.log(err);
         });
    }

    render()
    {
        return(

            <FadeIn>
                <div className="row">

                    <div className="text-left col-md-2">
                    <a onClick={this.returnProductos}  type="button" style={{cursor: 'pointer'}}  className="bg-primary border border-primary rounded p-1 superBoton text-left text-success">
                    <i className="align-middle fa fa-arrow-left text-white" style={{fontSize: '24px'}}></i>
                        <label className="mt-2 text-white d-md-inline" style={{cursor: 'pointer', fontSize: '15px'}}>Atras</label>
                    </a>
                    </div>

                </div>
                <form  onSubmit={this.onSubmit} id="formNewProducto" className="form-horizontal border pt-4 pb-4 mt-3">
                    <div className="row">
                        <h2 className="mx-auto col-12"  style={{
                            textAlign: 'center',
                            fontFamily: 'Roboto',
                            color: '#771414',
                        }}>
                           Agregar un Nuevo producto
                        </h2>
                        <small id="emailHelp" className="form-text text-center text-muted col-12"> 
                           Llena los siguientes campos para agregar un Nuevo Producto al catalogo
                        </small>   
                    </div>
                    <div className="row mt-4">
                        <div className="mx-auto border p-5 bg-light col-lg-7 col-sm-12">
                            
                            <div className="mb-3 mt-3" id="miAlert2">
                            </div>
                            <div className="form-group">
                                <label>Nombre</label>
                                <input type="text" className="form-control" id="nombre" name="nombre" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Marca</label>
                                <input type="text" className="form-control" id="marca" name="marca" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Clasificación</label>
                                <input type="text" className="form-control" id="clasificacion" name="clasificacion" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Ingrediente Activo</label>
                                <input type="text" className="form-control" id="ingredienteActivo" name="ingredienteActivo" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$" required/>
                            </div>

                            <div className="form-group">
                                <label>Precio Unitario</label>
                                <input type="number" className="form-control" id="precioUnitario" name="precioUnitario" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Stock</label>
                                <input type="number" className="form-control" id="stock" name="stock" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$" required/>
                            </div>

                            <div className="form-group">
                                <label>Descripcion</label>
                                <textarea type="text" className="form-control" id="descripcion" name="descripcion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>
                            <div className="form-group">
                                <label>Forma de Aplicación</label>
                                <textarea type="text" className="form-control" id="formaAplicacion" name="formaAplicacion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>

                            <div className="form-group">
                                <label>Foto</label>
                                <input required type="file" className="form-control" id="imagenProducto" name="imagenProducto" accept="image/*"></input>
                                <small className="form-text text-muted">Sube una imagen del Producto</small>
                            </div>
                            
                            <div className="form-row">
                                <button type="submit" className="btn btn-primary mx-auto">Enviar</button>
                            </div>

                            <div className="mt-4" id="miAlert">
                            </div>
                        </div>
                    </div>
                </form>
            </FadeIn>

        );
    }
}

export default NuevoProducto;