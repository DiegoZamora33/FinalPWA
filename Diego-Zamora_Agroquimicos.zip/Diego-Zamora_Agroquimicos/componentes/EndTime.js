import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class EndTime extends Component
{
    render()
    {
        if(this.props.login == 'true')
        {
            return(
                <div>
                        ronfoernfoernforn
                </div>
            );
        }
        else
        {
            return(
                <div>
                    <Link className="btn btn-primary" to="/login">Volver al Login</Link>
                </div>
             );
        }
    }
}
  
export default EndTime;