import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class SobreNosotrosPrincipal extends Component
{
    render()
    {
        return(       
       
            <section className="SectionsobreNosotros mt-0">
                <div className="container">
                    <div className="row">
                        <div className="div_sobreN shadow">
                            <div className="sobreNosotros">
                                <h2>
                                    SOBRE NOSOTROS
                                </h2>
                                <hr className="hrMediano"/>
                                <h1>
                                    SOMOS UNA EMPRESA COMPROMETIDA A BRINDARLE AL CLIENTE PRODUCTOS DE CALIDAD Y COMPROBADOS QUE DAN RESULTADOS
                                </h1>
                                <div className="sobreNosotrosTexto">
                                    <p>
                                        Nuestra empresa se dedica al cultivo de,  <b>Durazno </b> 
                                        y <b> Ciruela</b>, que cosechamos con las más <b>exigentes estándares de inspección</b>, pues nos definimos 
                                        por nuestro compromiso con el consumidor.
                                    </p>
                                </div>
                                
                                <Link style={{textDecoration: 'none'}} to="/sobre-nosotros"><button className="botonSobreNosotrosIndex">CONÓCENOS</button></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
       
       );
    }
}

export default SobreNosotrosPrincipal;