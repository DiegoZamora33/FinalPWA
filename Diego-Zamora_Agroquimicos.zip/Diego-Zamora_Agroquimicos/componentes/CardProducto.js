import React, { Component } from 'react';
import { Link } from 'react-router-dom';


class CardProducto extends Component
{
    
    constructor(props) 
    {
        super(props);
        this.getPerfilProducto = this.getPerfilProducto.bind(this);
    }
    
    getPerfilProducto(e) 
    {
        localStorage.setItem('idProducto', e.target.id)
        //window.location = '/perfil-producto';
    }

    render()
    {
        return(

            <div className="col-md-4 mb-5">
                <div className="food-item">
                    <img src={this.props.imagen} alt={this.props.nombre} className="escalar"/>
                    <div className="price">${this.props.precio}</div>
                    <div className="text-content">
                        <h4>{this.props.nombre} de {this.props.marca}</h4>
                        <p>
                            <b>{this.props.clasificacion}</b>  <br/>
                            <b>Ingrediente Activo:</b> {this.props.ingrediente} <br/>
                            <b>Descripción:</b> {this.props.descripcion} <br/>
                        </p>
                        
                        <div className="row">
                            <Link to="/perfil-producto" className="btn btn-info btn-sm mx-auto" id={this.props.quienSoy} onClick={this.getPerfilProducto} >Mas Informacion</Link>
                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default CardProducto;