import React, { Component } from 'react';

// Import de mis Componentes
import CardAsesoriaAdmin from './CardAsesoriaAdmin';
import FadeIn from 'react-fade-in';

class StockAsesorias extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getProductos();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getProductos = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/asesorias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }

    render()
    {
        return(

                <FadeIn>
                    <div className="row mb-1">
                    </div> 
                    <CardAsesoriaAdmin data = {this.state.data} /> 
                </FadeIn>

        );
    }
}

export default StockAsesorias;