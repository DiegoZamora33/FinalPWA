import React, { Component } from 'react';

class NoticiasPrincipal extends Component
{
    render()
    {
        return(     
            <section id="book-table">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                    <div className="heading">
                                        <div className="noticiasDiv">
                                            <div className="noticiasContainer">
                                                <h2>MANTENTE INFORMADO</h2>
                                                <hr className="hrMediano"/>
                                                <a href="/noticias">
                                                    <button className="botonNoticiasIndex">
                                                        NOTICIAS
                                                    </button>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </section>
       
       );
    }
}

export default NoticiasPrincipal;