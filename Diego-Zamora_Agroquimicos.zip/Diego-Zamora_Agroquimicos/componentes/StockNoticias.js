import React, { Component } from 'react';
import ReactDOM from 'react-dom';

// Import de mis Componentes
import CardNoticiaAdmin from './CardNoticiaAdmin';
import NuevoProducto from './NuevoProducto';
import FadeIn from 'react-fade-in';
import NuevaNoticia from './NuevaNoticia';

class StockNoticias extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getProductos();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getProductos = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/noticias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }

    newProducto = async () =>
    {
        ReactDOM.render(
            <NuevaNoticia/>,
        document.getElementById('mostrador'));
    }



    render()
    {
        return(

                <FadeIn>
                    <div className="row mb-1">
                            <div className="mx-auto">
                                <button type="button" className="btn btn-primary" onClick={this.newProducto} data-toggle="modal" data-target="#modalNewProducto">
                                    
                                    <i className="fa fa-plus-circle"></i>
                                    <span className="ml-2">Nueva Noticia</span>
                                </button>
                            </div>
                    </div> 
                    <CardNoticiaAdmin data = {this.state.data} /> 
                </FadeIn>

        );
    }
}

export default StockNoticias;