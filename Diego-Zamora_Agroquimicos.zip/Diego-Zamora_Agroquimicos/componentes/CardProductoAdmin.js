import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Route, Redirect } from 'react-router-dom';

// Import de mis Componentes
import EditProducto from './EditProducto';
import StockProductos from './StockProductos';

class CardProductoAdmin extends Component
{
    constructor(props) 
    {
        super(props);
        this.state = {
            idProducto : ' ',
        };
        this.getPerfilProducto = this.getPerfilProducto.bind(this);
        this.deleteProducto = this.deleteProducto.bind(this);
        this.showDelProducto = this.showDelProducto.bind(this);
        this.hideDelProducto = this.hideDelProducto.bind(this);
    }

    showDelProducto(e) 
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div className="alert alert-info" id="mimodal">
                 <label>Desea eliminar este Registro??</label><br/>
                <button id={e.target.id} onClick={this.deleteProducto} className="btn btn-warning btn-sm ml-1" >SI</button>
                
                <button id={e.target.id} onClick={this.hideDelProducto} className="btn btn-info btn-sm ml-1" >NO</button>
            </div>,
        document.getElementById('miConfirm'+e.target.id));
         
    }

    hideDelProducto(e)
    {
        e.preventDefault();
        
        ReactDOM.render(
            <div>

            </div>,
        document.getElementById('miConfirm'+e.target.id));
    }

    deleteProducto(e)
    {
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/delProducto';
        var formData = new FormData();
        formData.append("idProducto", e.target.id);

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
             
           console.log(texto['respuesta'])
            ReactDOM.render(
                <StockProductos/>,
            document.getElementById('mostrador'));
            
         })
         .catch(function(err) {
            console.log(err);
         })
    }

    getPerfilProducto(e) 
    {
        ReactDOM.render(
            <EditProducto get={e.target.id} />,
        document.getElementById('mostrador'));
    }

    render()
    {
        return(

            <div className="col-md-4 mb-5">
                <div className="food-item" >
                    <img src={this.props.imagen} className="escalar"/>
                    <div className="price">${this.props.precio}</div>
                    <div className="text-content">
                        <h4>{this.props.nombre} de {this.props.marca}</h4>
                        <p>
                            <b>{this.props.clasificacion}</b>  <br/>
                            <b>Ingrediente Activo:</b> {this.props.ingrediente} <br/>
                            <b>Descripción:</b> {this.props.descripcion} <br/>
                        </p>
                        
                        <div className="row mt-2">
                            <div className="mx-auto" id={'miConfirm'+this.props.quienSoy}>
                            </div>
                        </div>
                        <div className="row">
                            <div className="mx-auto">
                                <button id={this.props.quienSoy} onClick={this.getPerfilProducto} className="btn btn-warning btn-sm mr-1" >Editar</button>
                                <button id={this.props.quienSoy} onClick={this.showDelProducto} className="btn btn-danger btn-sm ml-1" >Eliminar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default CardProductoAdmin;