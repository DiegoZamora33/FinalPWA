import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// Import de mis Componentes
import CardProducto from './CardProducto';

class ProductosPrincipal extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getProductos();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getProductos = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/productos')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }
    render()
    {
        return(

            <section className="featured-food">
                    <div className="container">
                        <div className="row">
                            <div className="headingIndex mx-auto">
                                <h2>PRODUCTOS</h2>
                                <hr className="hrMedianoD"/>
                                <h1 className="mt-5">LO QUE OFRECEMOS</h1>
                                <p>
                                    Productos para tu cultivo de Durazno y Ciruela. Podrás lograr una cosecha dulce de buen tamaño y libre manchas.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            {
                                this.state.data ? 
                                    this.state.data.map( 
                                        e =>
                                            <CardProducto
                                                quienSoy = {e.idProducto}
                                                key = {e.idProducto}
                                                marca = {e.marca}
                                                imagen = {e.imagen}
                                                nombre = {e.nombre}
                                                precio = {e.precioUnitario}
                                                clasificacion = {e.clasificacion}
                                                ingrediente = {e.ingredienteActivo}
                                                descripcion = {e.descripcion}
                                            />
                                    )
                                : <h1 className="mx-auto">NO DATA :(</h1>
                            }
                        </div>
                        <div className="row mt-0">
                            <div className="verMasProductos mt-0">
                                <Link to="/productos"><p><u>VER MÁS PRODUCTOS</u></p></Link>
                            </div>
                        </div>
                    </div>
                </section>

        );
    }
}

export default ProductosPrincipal;