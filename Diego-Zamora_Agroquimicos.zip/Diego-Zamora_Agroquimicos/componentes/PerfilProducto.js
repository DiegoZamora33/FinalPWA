import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import background from '../img/pears-1748034.jpg';


// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import FooterPrincipal from '../componentes/FooterPrincipal';
import FadeIn from 'react-fade-in';
import StockProductos from './StockProductos';

class PerfilProducto extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            data : [],
            idProducto : '0'
        };
    }

    async componentDidMount()
    {
        await this.getProducto();
        if(localStorage.idProducto)
        {
            this.setState({
                idProducto : localStorage.idProducto
            })
        }
        else
        {
            this.setState({
                idProducto : this.props.get
            })
        }
    }

    returnProductos = async () =>
    {
        ReactDOM.render(
            <StockProductos/>,
        document.getElementById('mostrador'));
    }

    getProducto = async () =>  
    {
        
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/getProducto', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idProducto : localStorage.idProducto,
            })
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            return texto;
         })
         .catch(function(err) {
            console.log(err);
         });

         this.setState({
             data: res['respuesta'][0]
         });
        console.log(res['respuesta']);
    }


    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Productos"
                    p1 = "Bayer, Syngenta, Pioneer y otras marcas mas."
                    p2 = " Aqui podrás encontrar de todo los productos necesarios para tus hortalizas y arboles frutales, control de plagas, hormonas de crecimiento y fertilizantes. "
                    top = '12%'
                    bottom = '28%'
                />
                <form className="form-horizontal border pt-4 pb-5 mt-5">
                    <div className="row">
                        <img className="col-lg-4 col-sm-12 mx-auto" src={this.state.data.imagen} />  
                    </div>
                    <div className="row mt-4">
                        <div className="mx-auto border p-5 bg-light col-lg-7 col-sm-12">
                            
                            <div className="form-group">
                                <h3 className="mx-auto">Precio: ${this.state.data.precioUnitario}</h3>
                            </div>
                            <div className="form-group">
                                <label>Nombre</label>
                                <input readOnly value={this.state.data.nombre} type="text" className="form-control" id="nombre" name="nombre" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Marca</label>
                                <input readOnly value={this.state.data.marca}  type="text" className="form-control" id="marca" name="marca" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Clasificación</label>
                                <input readOnly value={this.state.data.clasificacion}  type="text" className="form-control" id="clasificacion" name="clasificacion" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$"  required/>
                            </div>
                            <div className="form-group">
                                <label>Ingrediente Activo</label>
                                <input readOnly value={this.state.data.ingredienteActivo}  type="text" className="form-control" id="ingredienteActivo" name="ingredienteActivo" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$" required/>
                            </div>
                            <div className="form-group">
                                <label>Stock</label>
                                <input  readOnly value={this.state.data.stock}  type="number" className="form-control" id="stock" name="stock" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$" required/>
                            </div>

                            <div className="form-group">
                                <label>Descripcion</label>
                                <textarea  readOnly value={this.state.data.descripcion}  type="text" className="form-control" id="descripcion" name="descripcion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>
                            <div className="form-group">
                                <label>Forma de Aplicación</label>
                                <textarea  readOnly value={this.state.data.formaAplicacion}  type="text" className="form-control" id="formaAplicacion" name="formaAplicacion" row="7"> </textarea>
                                <small className="form-text text-muted">Describe en que consiste</small>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="mx-auto">
                            <a className="btn btn-warning btn-lg mt-5" >Comprar</a>
                        </div>
                    </div>
                </form>
            <FooterPrincipal/>
            </FadeIn>

        );
    }
}

export default PerfilProducto;