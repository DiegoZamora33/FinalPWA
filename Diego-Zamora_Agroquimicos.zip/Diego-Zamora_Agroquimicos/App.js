import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';



// Import de mis Vistas
import Principal from './vistas/Principal';
import Productos from './vistas/Productos';
import Maquinaria from './vistas/Maquinaria';
import Noticias from './vistas/Noticias';
import SobreNosotros from './vistas/SobreNosotros';
import NecesitoAsesoria from './vistas/NecesitoAsesoria';
import PerfilProducto from './componentes/PerfilProducto';

// Para Login
import Login from './componentes/Login';
import Home from './vistas/Home';


//Ruta no Valida
import NotFound from './vistas/NotFound';
import PerfilMaquinaria from './componentes/PerfilMaquinaria';


function App() {
  return (
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Principal} />
          <Route exact path="/productos" component={Productos} />
          <Route exact path="/maquinaria" component={Maquinaria} />
          <Route exact path="/noticias" component={Noticias} />
          <Route exact path="/sobre-nosotros" component={SobreNosotros} />
          <Route exact path="/necesito-asesoria" component={NecesitoAsesoria} />
          <Route exact path="/perfil-producto" component={PerfilProducto} />
          <Route exact path="/perfil-maquinaria" component={PerfilMaquinaria} />
          
          <Route exact path="/login" component={Login} />
          <Route exact path="/home" component={Home} />

          <Route component={NotFound} />
        </Switch>
      </BrowserRouter>
  );
}

export default App;
