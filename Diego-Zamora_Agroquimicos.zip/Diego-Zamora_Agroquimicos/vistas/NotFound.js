import React, { Component } from 'react';
import FadeIn from 'react-fade-in';

class NotFound extends Component
{
    render()
    {
        return(
            <FadeIn>
                <div className="flex-center position-ref full-height styleFont">
                    <div className="content">
                        <div className="title">
                            Sorry, the page you are looking for could not be found.               
                        </div>
                    </div>
                </div>
            </FadeIn>
        );
    }
}

export default NotFound;