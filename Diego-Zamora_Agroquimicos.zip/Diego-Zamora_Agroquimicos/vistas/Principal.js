import React, { Component } from 'react';
import FadeIn from 'react-fade-in';

// Import de mis Componentes
import HeaderPrincipal from '../componentes/HeaderPrincipal';
import Carrucel from '../componentes/Carrucel';
import ProductosPrincipal from '../componentes/ProductosPrincipal';
import NoticiasPrincipal from '../componentes/NoticiasPrincipal';
import MaquinariaPrincipal from '../componentes/MaquinariaPrincipal';
import SobreNosotrosPrincipal from '../componentes/SobreNosotrosPrincipal';
import FooterPrincipal from '../componentes/FooterPrincipal';

class Principal extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : ' ',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getNoticias();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getNoticias = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/mix')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }
    
    render()
    {
        return(
            <FadeIn>
                <HeaderPrincipal/>
                <Carrucel data = {this.state.data} />
                <ProductosPrincipal/>
                <NoticiasPrincipal/>
                <MaquinariaPrincipal/>
                <SobreNosotrosPrincipal/>
                <FooterPrincipal/>
            </FadeIn>
        );
    }
}

export default Principal;