import React, { Component } from 'react';
import FadeIn from 'react-fade-in';
import background from '../img/tractor-5002265.jpg';

// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import Footer from '../componentes/FooterPrincipal';
import CardNoticia from '../componentes/CardNoticia';

class Noticias extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getNoticias();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getNoticias = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/noticias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }

    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Noticias"
                    p1 = "No te pierdas los ultimos avances y nuevos productos que salen al mercado"
                    p2 = " Aqui podrás encontrar todas las noticias referentes a el area de la agricultura, avances tecnologicos, nuevas tecnias de cultivo, avances geneticos y simpre seras de los primeros en darte cuentas de las nuevas variedades que salen al mercado"
                    top = '12%'
                    bottom = '28%'
                />
                <CardNoticia data = {this.state.data} />  
                <Footer/>
            </FadeIn>
        );
    }
}

export default Noticias;