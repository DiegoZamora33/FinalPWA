import React, { Component } from 'react';
import FadeIn from 'react-fade-in';
import background from '../img/tractor-4575106.jpg';

// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import MaquinariaPrincipal from '../componentes/MaquinariaPrincipal';
import Footer from '../componentes/FooterPrincipal';

class Maquinaria extends Component
{
    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Maquinaria"
                    p1 = "Jhon Deer, FORD, Kubota y otras marcas mas."
                    p2 = " Aqui podrás encontrar la maquinaria mas nueva, profesional y de potencia. Necesaria para tus huertas. Tractores, Motogüadañas, Motosierras y Accesorios para tu tractor"
                    top = '12%'
                    bottom = '28%'
                />
                <MaquinariaPrincipal/>   
                <Footer></Footer>
            </FadeIn>
        );
    }
}

export default Maquinaria;