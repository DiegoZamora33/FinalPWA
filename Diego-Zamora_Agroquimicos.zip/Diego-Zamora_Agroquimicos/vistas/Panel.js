import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FadeIn from 'react-fade-in';
import $ from 'jquery';
import zamora2 from '../img/zamora2.png';


// Import de mis Componentes
import '../componentes/dinamico';
import StockProductos from '../componentes/StockProductos';
import StockMaquinaria from '../componentes/StockMaquinaria';
import StockNoticias from '../componentes/StockNoticias';
import StockAsesorias from '../componentes/StockAsesorias';

class Panel extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            user: ' ',
            password: ' ',
            login: 'true',
        };
    }

    async componentDidMount()
    {
        await this.getToken();
    }

    getToken = async () =>  
    {
        
    }

    miOff()
    {
        document.getElementById('home').className = " ";
        document.getElementById('productos').className = " ";
        document.getElementById('maquinaria').className = " ";
        document.getElementById('noticias').className = " ";
        document.getElementById('asesorias').className = " ";
    }

    home = async () =>
    {
        this.miOff();
        document.getElementById('home').className = "active mt-2 mb-1";

        ReactDOM.render(
            <FadeIn>
                <h2>Bienvenido</h2>
                <h4>Estas Registrado como: Administrador</h4>
                <p>Recuerda siempre cerrar tu sesión</p>
            </FadeIn>,
        document.getElementById('mostrador'));
    }

    productos = async () =>
    {
        this.miOff();
        document.getElementById('productos').className = "active mt-2 mb-1";

        ReactDOM.render(
            <FadeIn>
                <StockProductos/>
            </FadeIn>,
        document.getElementById('mostrador'));
    }

    maquinaria = async () =>
    {
        this.miOff();
        document.getElementById('maquinaria').className = "active mt-2 mb-1";

        ReactDOM.render(
            <FadeIn>
                <StockMaquinaria/>
            </FadeIn>,
        document.getElementById('mostrador'));
    }

    noticias = async () =>
    {
        this.miOff();
        document.getElementById('noticias').className = "active mt-2 mb-1";

        ReactDOM.render(
            <FadeIn>
                <StockNoticias/>
            </FadeIn>,
        document.getElementById('mostrador'));
    }

    asesorias = async () =>
    {
        this.miOff();
        document.getElementById('asesorias').className = "active mt-2 mb-1";

        ReactDOM.render(
            <FadeIn>
                <StockAsesorias/>
            </FadeIn>,
        document.getElementById('mostrador'));
    }

    render()
    {
        return(
                <FadeIn>
                <div className="wrapper">
                    <div id="lateral">
                        <nav id="sidebar" className="">
                            <div className="sidebar-header">
                                <img src={zamora2} width="230" alt="logo_principal"/>
                            </div>
                
                            <ul className="list-unstyled components">
                                <li className="active mt-2" onClick={this.home} id="home">
                                    <a style={{cursor: 'pointer'}}>
                                        <i className="fa fa-home"></i>
                                        <span className="CTAs">Home</span>
                                    </a>
                                </li>
                
                                <li className="mt-1 text-center" onClick={this.productos} id="productos">
                                    <a style={{cursor: 'pointer'}}>
                                        <i className="fa fa-flask"></i>
                                        <span className="CTAs">Productos</span>
                                    </a>
                                </li>
                
                                <li className="mt-1" onClick={this.maquinaria} id="maquinaria">
                                    <a style={{cursor: 'pointer'}}>
                                        <i className="fa fa-wrench"></i>
                                        <span className="CTAs">Maquinaria</span>
                                    </a>
                
                                </li>
                
                                <li className="mt-1" onClick={this.noticias} id="noticias">
                                    <a style={{cursor: 'pointer'}}>
                                        <i className="fa fa-calendar"></i>
                                        <span className="CTAs">Noticias</span>
                                    </a>
                                </li>

                                <li className="mt-1" onClick={this.asesorias} id="asesorias">
                                    <a style={{cursor: 'pointer'}}>
                                        <i className="fa fa-edit"></i>
                                        <span className="CTAs">Asesorias</span>
                                    </a>
                                </li>

                            </ul>
                
                            <div className="d-lg-block d-md-block d-sm-none">
                            <ul className="list-unstyled CTAs ">
                                <li>
                                    <a href="/login" className="btn btn-danger pl-5">
                                        <i className="fa fa-sign-out"></i>
                                        Cerrar sesión
                                    </a>
                                </li>
                            </ul>
                            </div>
                
                
                            <ul className="d-lg-none d-md-none d-sm-block">
                                <li>
                                    <a href="/login" className="btn-sm btn-danger pl-1">
                                    <i className="fa fa-sign-out"></i>
                                        <label className="cerrarSesionR">Cerrar sesión</label>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>

                    <div id="content">

                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                            <div className="container-fluid">

                                <button type="button" id="sidebarCollapse" className="btn btn-primary">
                                    <i className="fa fa-align-left"></i>
                                    <span></span>
                                </button>
                                <button className="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <i className="fa fa-align-justify"></i>
                                </button>

                                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul className="ml-auto">
                                        <li className="nav-item active">
                                        <form>
                                            <div className="form-group mt-lg-auto mt-md-3 mt-sm-4 mt-4">
                                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Buscar"/>
                                            </div>
                                        </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>

                        <div className="container text-center" id="mostrador">

                            <h2>Bienvenido</h2>
                            <h4>Estas Registrado como: Administrador</h4>
                            <p>Recuerda siempre cerrar tu sesión</p>
                        </div>
                    </div>
                </div>
                
                </FadeIn>
        );
    }
}

export default Panel;