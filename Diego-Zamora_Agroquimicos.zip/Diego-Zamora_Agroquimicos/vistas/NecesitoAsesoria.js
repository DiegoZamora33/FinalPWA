import React, { Component } from 'react';
import FadeIn from 'react-fade-in';
import ReactDOM from 'react-dom';
import $ from 'jquery';
import background from '../img/tomato-2643775.jpg';

// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import MaquinariaPrincipal from '../componentes/MaquinariaPrincipal';
import Footer from '../componentes/FooterPrincipal';

class NecesitoAsesoria extends Component
{
    onSubmit(e){
        e.preventDefault();

        let url = 'https://zamoritta33.com/agroquimicos-zamora/public/API/newAsesoria';
        var formData = new FormData();
        formData.append("nombre", $('#nombre').val());
        formData.append("telefono", $('#telefono').val());
        formData.append("correo", $('#correo').val());
        formData.append("texto", $('#texto').val());

        fetch(url, {
            method: "POST",
            body: formData,
            headers: {
            }
         })
         .then(function(response) 
         {
            if(response.ok) 
            {
                return response.json()

            } else {
                throw "Error en la llamada Ajax";
            }
         
         })
         .then(function(texto) 
         {
            ReactDOM.render(
                <div class="alert alert-info">
                   Eviado con Exito, uno de nuestros expertos se pondrá en contacto contigo en un trascurso de 7 dias habiles
                </div>,
            document.getElementById('miAlert'));
            ReactDOM.render(
                <div class="alert alert-info">
                    Eviado con Exito, uno de nuestros expertos se pondrá en contacto contigo en un trascurso de 7 dias habiles
                </div>,
            document.getElementById('miAlert2'));
            $('#formNewProducto').trigger("reset");
            console.log(texto['respuesta']);
         })
         .catch(function(err) {
            console.log(err);
         });
    }
    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Asesorias"
                    top = '8%'
                    p1="Resolvemos todos tus problemas que tengas"
                    p2="Asesoria Tecnica, Preparacion de Productos, Uso de Maquinaria y tecnicas de poda"
                />

                <div className="container mt-5 mb-5">
                    <form onSubmit={this.onSubmit} id="formNewProducto" class="form-horizontal border pt-4 pb-4">
                        <div class="row">
                            <h2 className="mx-auto col-12"  style={{
                                textAlign: 'center',
                                fontFamily: 'Roboto',
                                color: '#771414',
                            }}>
                                Asesorias Completamente Gratis!!!
                            </h2>
                            <small id="emailHelp" class="form-text text-center text-muted col-12"> 
                                Dejanos tu Pregunta o Problema y uno de nuestro profersionales y expertos se pondrá en contacto contigo
                            </small>   
                        </div>
                        <div class="row mt-4">
                            <div className="mx-auto border p-5 bg-light col-lg-6 col-sm-12">
                                <div className="mb-3 mt-3" id="miAlert2">
                                </div>

                                <div class="form-group">
                                    <label for="nombre">Nombre Completo</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder=" " title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,100}$" maxlength="50" required/>
                                </div>
                                <div class="form-group">
                                    <label for="apellidoPaterno">Numero de Telefono</label>
                                    <input type="number" class="form-control" id="telefono" name="telefono" title="No se admiten caracteres especiales como '(){}?¿' etc..." pattern="^[a-zA-ZñÑáéíóú.\s]{0,50}$" maxlength="50" required/>
                                </div>
                                <div class="form-group">
                                    <label for="apellidoMaterno">Correo Electronico</label>
                                    <input type="email" class="form-control" id="correo" name="correo" required/>
                                </div>
                                <div class="form-group">
                                    <label for="patrocinio">Escribenos tu duda</label>
                                    <textarea required type="text" class="form-control" id="texto" name="texto" row="5"> </textarea>
                                    <small id="emailHelp" class="form-text text-muted"> Escriba su duda o problema </small>
                                </div>
                                <div className="mb-3 mt-3" id="miAlert">
                                 </div>

                                <div class="form-row">
                                    <button type="submit" class="btn btn-primary mx-auto">Enviar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <Footer></Footer>
            </FadeIn>
        );
    }
}

export default NecesitoAsesoria;