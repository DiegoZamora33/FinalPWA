import React, { Component } from 'react';

// Import de mis componentes
import EndTime from '../componentes/EndTime';
import Panel from './Panel';
import FadeIn from 'react-fade-in';

class Home extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            user: ' ',
            password: ' ',
            login: 'true',
        };
    }

    async componentDidMount()
    {
        await this.getToken();
    }

    getToken = async () =>  
    {
        if(localStorage.user != ' ')
        {
            this.setState({
                user: localStorage.user,
                password: localStorage.pass,
                login: 'true',
            });
        }
        else
        {
            this.setState({
                login: 'false',
            });
        }

        localStorage.setItem('user', ' ');
        localStorage.setItem('pass', ' ');
    }

    render()
    {
        return(
            <FadeIn>
            {
                this.state.user != ' ' ?

                        <Panel/>


                    :
                        <div>
                            <h1>La sesión ha expirado :(</h1>
                            <h2>Serás reedirigido al login, intenta iniciar sesión de nuevo...</h2>
                            <EndTime login={this.state.login}/>
                        </div>
            }
            </FadeIn>
        );
    }
}

export default Home;