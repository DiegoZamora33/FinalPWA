import React, { Component } from 'react';
import FadeIn from 'react-fade-in';
import background from '../img/pears-1748034.jpg';

// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import ProductosPrincipal from '../componentes/ProductosPrincipal';
import Footer from '../componentes/FooterPrincipal';

class Productos extends Component
{
    constructor(props) 
    {
        super(props)
        this.state = {
            token : 'ju',
            data : [],
        };
    }

    async componentDidMount()
    {
        await this.getToken();
        await this.getNoticias();
    }

    getToken = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/token')
        let data = await res.json()

        this.setState({
            token: data['token']
        })
    }

    getNoticias = async () =>  
    {
        let res = await fetch('https://zamoritta33.com/agroquimicos-zamora/public/API/noticias')
        let data = await res.json()

        this.setState({
            data: data['respuesta'] 
        })
    }


    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Productos"
                    p1 = "Bayer, Syngenta, Pioneer y otras marcas mas."
                    p2 = " Aqui podrás encontrar de todo los productos necesarios para tus hortalizas y arboles frutales, control de plagas, hormonas de crecimiento y fertilizantes. "
                    top = '12%'
                    bottom = '28%'
                />
                <ProductosPrincipal/>   
                <Footer></Footer>
            </FadeIn>
        );
    }
}

export default Productos;