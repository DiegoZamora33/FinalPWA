import React, { Component } from 'react';
import FadeIn from 'react-fade-in';
import background from '../img/vegetable-plot-794571.jpg';
import tractor from '../img/tractor-5214993.jpg';

// Import de mis Componentes
import HeaderSecondary from '../componentes/HeaderSecondary';
import FooterPrincipal from '../componentes/FooterPrincipal';


class SobreNosotros extends Component
{
    render()
    {
        return(
            <FadeIn>
                <HeaderSecondary 
                    imagen = {background} 
                    titulo = "Sobre Nosotros"
                    p1 = "Conoce quiénes somos"
                    top = '12%'
                    bottom = '28%'
                />
                <div className="container mt-5">
                    <div className="row">
                        <p className="w-auto mx-auto" style={{
                            fontSize: '18px',
                        }}>
                            Empresa orgullosamente Michoacana
                        </p>
                    </div>

                    <div className="row">  
                        <div className="col-12 mx-auto">
                            <hr className="hrMedianoD w-75 mx-auto"/> 
                        </div>
                        <div className="col-lg-12 col-sm-7 mx-auto">
                            <h1 className="mt-3" style={{
                                textAlign: 'center',
                                fontFamily: 'Roboto',
                                color: '#771414',
                                fontSize: '30px',
                            }}>
                                AGROQUIMICOS ZAMORA
                            </h1>
                        </div>
                    </div>

                    <div className="row mt-5">
                        <p className="text-dark text-center col-lg-7 col-sm-12 mx-auto" style={{
                            fontSize: '18px',
                        }}>
                            Somos una empresa certificada por el cumplimiento de las 
                            <b>  Buenas Prácticas Agricolas en la Producción Primaria  </b> 
                            bajo la Secretaría de Agricultura y Desarrollo Rural Clave: AC-PD-16-19-473
                        </p>
                    </div>

                    <div className="row mt-4">
                        <img className="mx-auto" src="http://equipo5.fabricasoft.website/img/SENASICA.png" width="450"/>
                    </div>
                </div>
                
                <div className="mt-5 row" id="div_mision"> 

                    <div className="div_misionTransparente col-lg-6 col-sm-12" >
                        <div id="txtMissionContainer">
                            <p className="txt_mision">
                                <b>Misión</b>
                            </p>
                        </div>
                        <div className="col-lg-9" id="txtMissionContenidoContainer">
                            <p className="txt_misionContenido mt-4">
                                Ofrecer productos de la mayor calidad, al mejor precio y brindar ayuda a nuestros clientes productores.
                            </p>
                        </div>
                    </div>

                    <div className="div_misionTransparente col-lg-6 col-sm-12" >
                        <div id="txtMissionContainer">
                            <p className="txt_mision">
                                <b>Visión</b>
                            </p>
                            </div>
                        <div className="col-lg-9" id="txtMissionContenidoContainer">
                            <p className="txt_misionContenido mt-4">
                                Ser una empresa distribuidora de excelencia, reconocida por sus productos de alta calidad y confiabilidad.
                            </p>
                        </div>
                    </div>
                </div> 
                
                <div id="div_history" className="row">

                    <img className="col-lg-6 col-sm-12 mx-0 px-0" src={tractor}/>
                   

                    <div id="div_historiaPII" className="col-lg-6 col-sm-12 mx-0">

                        <div id="txtMissionContainer">
                            <p className="txt_mision">
                                <b>Historia</b>
                            </p>
                        </div>
                        
                        <div id="txtHistoriaContenidoContainer">
                            <p className="txt_misionContenido mt-5">
                                AGROQUIMICOS ZAMORA es una empresa familiar
                                que un inicio comenzó con la Producción de Durazno y Ciruela, desde 
                                hace 20 años ha contribuido a ofrecer fruta de alta calidad y de proporcionar fuente 
                                de empleo a las personas en la ciudad de Huajumbaro. 
                            </p>
                        </div>

                        <p className="txt_mision">
                            <b>Valores</b>
                        </p>

                        <div id="txtHistoriaContenidoContainer">
                            <p className="txt_valores mt-5">
                                Calidad, Confiabilidad, Calidez, Transparencia y Pasión.
                            </p>
                        </div>
                    </div>
                </div>
                <div id="div_ubicanos">
                    <div id="txtUbicanos">
                        <p class="txt_mision">
                            <b>Ubícanos</b>
                        </p>
                    </div>
                    <div id="txtUbicanosContenido">
                        <p class="txt_Ubicanos">
                        <b>Domicilio conocido:</b> Huajumbaro de Guadalupe
                        S/N, C.P. 58963, Municipio de 
                        Zinapécuaro, Michoacán
                        </p>
                    </div>
                    <div id="mapaContainer">
                        <iframe id="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30456.23091201998!2d-100.60488154948865!3d19.863273609173905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d2d2dda482dd79%3A0xcd95423b2c9f24c4!2sZinap%C3%A9cuaro%2C%20Mich.!5e0!3m2!1ses-419!2smx!4v1591114893340!5m2!1ses-419!2smx" 
                            width="600" height="450" frameborder="0" style={{border:'0'}} allowfullscreen="" aria-hidden="false" tabindex="0">
                        </iframe>
                    </div>
                </div>
                <FooterPrincipal/>
            </FadeIn>
        );
    }
}

export default SobreNosotros;